import React from 'react';
import { Link } from 'react-router-dom';

import { ALL_LISTS } from './models/DATA';

function PageLists() {
  const listItems = ALL_LISTS.map(list => <li key={list.id}><Link to={'/list/' + list.id}>{list.title}</Link></li>)
  return (
    <ul>
      {listItems}
    </ul>
  );
}

export default PageLists;
