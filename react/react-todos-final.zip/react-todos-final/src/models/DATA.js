import TodoList from './TodoList';
import Todo from './Todo';

export const TODO_LIST = new TodoList(
  1,
  'Ma première liste',
  new Todo(1, 'Mon premier todo', true),
  new Todo(2, 'Acheter du lait', false),
  new Todo(3, 'Apprendre React', false),
);

export const ALL_LISTS = [
  TODO_LIST,
  new TodoList(2, 'Liste de courses', new Todo(10, 'Acheter du sopalin')),
  new TodoList(3, 'Une autre liste', new Todo(20, 'Ceci'), new Todo(21, 'Cela')),
];
