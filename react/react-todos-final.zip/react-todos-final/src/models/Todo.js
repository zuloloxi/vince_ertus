/**
 * @file
 * Class for a single Todo.
 */
class Todo {
  constructor(id, text, done = false) {
    this.id = id;
    this.text = text;
    this.done = done;
  }

  toggle() {
    this.done = !this.done;
  }

  toJson() {
    return {
      text: this.text,
      done: this.done,
    };
  }
}

export default Todo;