import React from 'react';
import './TodoItem.css';
import iconDelete from './assets/icon-delete.png';

function TodoItem({ todo, toggleTodo, deleteTodo }) {
  // @TODO: Use destructuring !!
  // const toggleTodo = () => {
  //   props.toggleTodo(props.todo);
  // }
  const handleDeleteTodo = (e) => {
    e.stopPropagation();
    deleteTodo(todo);
  }
  return (
    <li className={'list-group-item ' + (todo.done ? 'done' : '')} onClick={() => toggleTodo(todo)}>
      <img src={iconDelete} alt="Effacer" onClick={(e) => handleDeleteTodo(e)} /> {todo.text}
    </li>
  );
}

export default TodoItem;