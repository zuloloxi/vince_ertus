import React from 'react';
import TodoItem from './TodoItem';

function TodoList(props) {
  return (
    <ul className="list-group">
      {props.todos.map((todo) => <TodoItem key={todo.id} todo={todo} {...props} />)}
    </ul>
  );
}

export default TodoList;