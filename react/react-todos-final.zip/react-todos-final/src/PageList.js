import React, { useState } from 'react';
import { useParams } from 'react-router-dom';

import Button from '@material-ui/core/Button';

// Dialog
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

// Snackbar
import Snackbar from '@material-ui/core/Snackbar';

import TodoList from './TodoList';
import TodoForm from './TodoForm';
import Filters from './Filters';

import { ALL_LISTS } from './models/DATA';
import Todo from './models/Todo';

function PageList() {
  const { listId } = useParams();

  const [todos, setTodos] = useState(ALL_LISTS.find(list => list.id === Number(listId)).todos);
  const [filter, setFilter] = useState('ALL');
  const [open, setOpen] = useState(false);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [currentTodo, setCurrentTodo] = useState(null);

  const toggleTodo = (todo) => {
    const newTodos = todos.map(td =>
      td.id === todo.id ? {...td, done: !td.done} : td
    );
    setTodos(newTodos);
  }

  const deleteTodo = (todo) => {
    // Nouvelle version : ouvre une modale Material UI
    setCurrentTodo(todo);
    setOpen(true);
    // Ancienne version : confirme la suppression avec `window.confirm()`
    // if (window.confirm('Êtes-vous sûr(e) ?')) {
    //   const newTodos = todos.filter(td => td.id !== todo.id);
    //   setTodos(newTodos);
    // }
  }

  const createTodo = (todoText) => {
    const newId = getRandomInt(10, 1000);
    const newTodos = todos.concat(new Todo(newId, todoText));
    setTodos(newTodos);
    setOpenSnackbar(true)
  }

  const changeFilter = (filter) => {
    setFilter(filter);
  };

  const filterTodos = (todos, filter) => {
    return todos.filter(td => todoMatchFilter(td, filter));
  };

  const handleClose = (action) => {
    if (currentTodo && action === 'deleteTodo') {
      const newTodos = todos.filter(td => td.id !== currentTodo.id);
      setTodos(newTodos);
    }
    setOpen(false);
    setCurrentTodo(null);
  };

  const handleCloseSnackbar = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpenSnackbar(false);
  };

  return (
    <>
      <h3>Liste #{listId}</h3>
      <TodoForm createTodo={createTodo} />
      <TodoList todos={filterTodos(todos, filter)} toggleTodo={toggleTodo} deleteTodo={deleteTodo} />
      <Filters filter={filter} changeFilter={changeFilter} />
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Supprimer ?"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Êtes-vous sûr(e) de vouloir supprimer ce todo ?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => handleClose('')} color="primary">
            Non
          </Button>
          <Button onClick={() => handleClose('deleteTodo')} color="primary" autoFocus>
            Oui
          </Button>
        </DialogActions>
      </Dialog>
      <Snackbar
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
        message="Todo enregistré"
      />
    </>
  );
}

export default PageList;

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min; //The maximum is exclusive and the minimum is inclusive
}

/**
 * Return true if the given todo's status
 * matches the given filter.
 */
function todoMatchFilter(todo, filter) {
  switch (filter) {
    case 'ALL':
      return true;
    case 'DONE':
      return todo.done;
    case 'NOT_DONE':
      return !todo.done;
    default:
      return false;
  }
}
