import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route
} from 'react-router-dom';

import PageLists from './PageLists';
import PageList from './PageList';

import './App.css';

function App() {
  return (
    <Router>
      <div className="container">
        <h1>React Todos</h1>
        <div className="row">
          <div className="col-6">
            <Switch>
              <Route path="/list/:listId">
                <PageList />
              </Route>
              <Route path="/">
                <PageLists />
              </Route>
            </Switch>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;
