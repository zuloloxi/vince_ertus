import React from 'react';

function Filters({ filter, changeFilter }) {
  return (
    <div className="btn-group" role="group">
      <button type="button" className={'btn btn-' + (filter === 'ALL' ? 'primary' : 'secondary')} onClick={() => changeFilter('ALL')}>Tous</button>
      <button type="button" className={'btn btn-' + (filter === 'DONE' ? 'primary' : 'secondary')} onClick={() => changeFilter('DONE')}>Faits</button>
      <button type="button" className={'btn btn-' + (filter === 'NOT_DONE' ? 'primary' : 'secondary')} onClick={() => changeFilter('NOT_DONE')}>Pas faits</button>
    </div>
  );
}

export default Filters;