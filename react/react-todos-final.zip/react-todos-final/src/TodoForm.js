import React from 'react';

class TodoForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {todoText: ''};

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({todoText: event.target.value});
  }

  handleSubmit(event) {
    event.preventDefault();
    // console.log('A name was submitted: ' + this.state.todoText);
    this.props.createTodo(this.state.todoText);
    this.setState({todoText: ''});
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <div className="form-row">
          <div className="col-11">
            <input
              type="text"
              className="form-control mb-2 mr-sm-2 col-12"
              placeholder="Entrez votre todo"
              value={this.state.todoText}
              onChange={this.handleChange}
              />
          </div>
          <div className="col-1">
            <button type="submit" className="btn btn-primary mb-2">OK</button>
          </div>
        </div>
      </form>
    );
  }
}

export default TodoForm;