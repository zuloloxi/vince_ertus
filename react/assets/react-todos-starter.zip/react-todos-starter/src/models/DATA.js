import TodoList from './TodoList';
import Todo from './Todo';

export const TODO_LIST = new TodoList(
  1,
  'Ma première liste',
  new Todo('Mon premier todo', true),
  new Todo('Acheter du lait', false),
  new Todo('Apprendre React', false),
);

const td = new Todo('Acheter du lait', false);

export const ALL_LISTS = [
  TODO_LIST,
  new TodoList(2, 'Liste de courses', td, td, td),
  new TodoList(3, 'Une autre liste', td, td, td),
];
