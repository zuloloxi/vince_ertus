/**
 * @file
 * Class for a single Todo.
 */
class Todo {
  constructor(text, done = false) {
    this.text = text;
    this.done = done;
  }

  toggle() {
    this.done = !this.done;
  }

  toJson() {
    return {
      text: this.text,
      done: this.done,
    };
  }
}

export default Todo;