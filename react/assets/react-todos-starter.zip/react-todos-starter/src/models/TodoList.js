/**
 * @file
 * Class for a todo list, holding all the Todo's.
 */
import Todo from './Todo';

class TodoList {

  constructor(id, title, ...todos) {
    this.id = id;
    this.title = title;
    this.todos = [...todos];
  }

  addTodo(todo) {
    // Do not use Array.prototype.push() for immutability.
    this.todos = this.todos.concat(todo);
    // this.saveToStorage();
  }

  deleteTodo(todo) {
    // Do not use Array.prototype.splice() for immutability.
    this.todos = this.todos.filter(td => td.text !== todo.text);
    // this.saveToStorage();
  }

  toJson() {
    return {
      title: this.title,
      todos: this.todos.map(td => td.toJson())
    };
  }

  // Create a new list from JSON data
  static fromJson(jsonList) {
    return new TodoList(jsonList.title, ...jsonList.todos.map(todoJson => new Todo(todoJson.text, todoJson.done)));
  }
}

export default TodoList;