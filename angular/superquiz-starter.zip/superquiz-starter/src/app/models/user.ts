/**
 * @file
 * A user logged into the application.
 */

// Créer la classe User ici.
export class User {
  constructor(options: any) {}
}
