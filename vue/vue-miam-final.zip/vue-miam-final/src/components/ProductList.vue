<template>
  <div>

    <h2>Entrées</h2>
    <div class="row">
      <div class="col-sm-4" v-for="product in filterPlats('Entrée')" v-bind:key="product.id">
        <ProductItem v-bind:product="product" />
      </div>
    </div>

    <h2>Plats</h2>
    <div class="row">
      <div class="col-sm-4" v-for="product in filterPlats('Plat')" v-bind:key="product.id">
        <ProductItem v-bind:product="product" />
      </div>
    </div>

    <h2>Desserts</h2>
    <div class="row">
      <div class="col-sm-4" v-for="product in filterPlats('Dessert')" v-bind:key="product.id">
        <ProductItem v-bind:product="product" />
      </div>
    </div>

  </div>
</template>

<script>
import ProductItem from './ProductItem'

export default {
  name: 'ProductList',
  components: {
    ProductItem
  },
  inject: ['productService'],
  data: function() {
    return {
      products: []
    };
  },
  methods: {
    filterPlats: function(typePlat) {
      return this.products.filter(p => p.type === typePlat)
    }
  },
  created: function() {
    // console.log('ProductList créé');
    const vm = this;
    this.productService.getProducts().then(data => {
      // console.log('data', data);
      vm.products = data
    });
  },
}
</script>

<style scoped>
</style>
