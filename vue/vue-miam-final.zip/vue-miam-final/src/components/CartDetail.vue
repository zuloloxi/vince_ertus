<template>
  <div id="cart">

    <div class="row" v-if="productInfo.length > 0">
      <div class="col-md-8 offset-md-2">

        <h1>Panier</h1>

        <table class="table">
          <tbody>
            <tr v-for="(pInfo, index) in productInfo" :key="pInfo.product.id">
              <th scope="row">{{ index + 1 }}</th>
              <td>{{ pInfo.product.name }} ({{ pInfo.quantity }})</td>
              <td>
                <ProductButtons
                  :quantity="pInfo.quantity"
                  :product="pInfo.product"
                  />
              </td>
              <td>{{ pInfo.product.price * pInfo.quantity }}€</td>
            </tr>
          </tbody>
          <tfoot>
            <tr>
              <th></th>
              <th></th>
              <th></th>
              <th scope="col"><h3>{{ cartService.totalAmount }}€</h3></th>
            </tr>
          </tfoot>
        </table>

        <button type="button" class="btn btn-primary btn-lg btn-block">
          Valider le panier
        </button>
        <router-link class="btn btn-secondary btn-lg btn-block" to="/products">
          Annuler
        </router-link>

      </div>
    </div>

    <template v-else>
      <div class="alert alert-info" style="font-size:4em;">
        Votre panier est vide.<br>
        <i class="fas fa-cart-plus"></i> Veuillez ajouter des produits.
      </div>
    </template>
  </div>
</template>

<script>
import ProductButtons from './ProductButtons'

export default {
  name: 'CartDetail',
  inject: ['cartService'],
  components: {
    ProductButtons
  },
  data: function() {
    return {
      productInfo: {}
    }
  },
  computed: {},
  created: function() {
    this.productInfo = this.cartService.getAllProducts();
  }
}
</script>

<style scoped>
</style>
