<template>
  <p class="buttons">
    <button class="btn btn-default" @click.stop="remove" :disabled="quantity === 0">
      <i class="far fa-minus-square"></i>
    </button>
    <span class="number">
      {{quantity}}
    </span>
    <button class="btn btn-default btn2" @click.stop="add" :disabled="quantity >= 10">
      <i class="far fa-plus-square"></i>
    </button>
  </p>
</template>

<script>
export default {
  name: 'ProductButtons',
  props: {
    quantity: Number,
    product: Object
  },
  methods: {
    remove: function() {
      this.$emit('remove', this.product);
    },
    add: function() {
      this.$emit('add', this.product);
    }
  }
}


</script>

<style scoped>
</style>
