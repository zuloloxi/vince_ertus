<template>
  <div class="ml-auto">
    <div class="cart">
      <router-link to="/cart">
        <i class="fas fa-shopping-cart"></i>
        <span class="number">{{numTotalProducts}}</span>
      </router-link>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CartIcon',
  inject: ['cartService'],
  data: function() {
    return {
      // Fait en sorte que cartService participe à la détection de changement.
      // Sans cette ligne, peu importe qu'on utilise une computed property
      // ou une méthode pour récupérer le nombre d'articles dans le panier,
      // les changements ne sont pas détectés.
      cartService: this.cartService
    }
  },
  computed: {
    numTotalProducts: function() {
      return this.cartService.totalProducts
    }
  }
}
</script>

<style scoped>
</style>
