<template>
  <div class="card shadow-sm product-item" @click="gotoProduct()">
    <img :src="product.photo" class="card-img-top">
    <div class="card-body">
      <h5 class="card-title">
        {{trimmedName}}
        ({{product.price}}€)
      </h5>
      <p class="card-text">{{trimmedDescription}}</p>
      <ProductButtons
        :quantity="quantity"
        :product="product"
        @add="add($event)"
        @remove="remove($event)"
        />
    </div>
  </div>
</template>

<script>
import ProductButtons from './ProductButtons'

export default {
  name: 'Product',
  components: {
    ProductButtons
  },
  inject: ['cartService'],
  props: {
    product: Object
  },
  data: function() {
    return {
      quantity: 0
    }
  },
  computed: {
    trimmedName: function() {
      const name = this.product.name;
      return name.substr(0, 20) + (name.length > 20 ? '...' : '');
    },
    trimmedDescription: function() {
      const desc = this.product.description;
      return desc.substr(0, 100) + (desc.length > 100 ? '...' : '');
    }
  },
  methods: {
    add: function(product) {
      // console.log('add', product.name)
      this.cartService.addProduct(product)
      this.updateQuantity()
    },
    remove: function(product) {
      // console.log('remove', product.name)
      this.cartService.removeProduct(product)
      this.updateQuantity()
    },
    updateQuantity: function() {
      this.quantity = this.cartService.getQuantityForProduct(this.product.id)
    },
    gotoProduct: function() {
      this.$router.push({ path: `product/${this.product.id}` })
    }
  },
  created() {
    this.updateQuantity()
  }
}
</script>

<style scoped>
</style>
