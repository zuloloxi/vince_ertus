<template>
  <div>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb" style="background-color: #e3f2fd;">
        <li class="breadcrumb-item"><router-link to="/products">Retour à la liste</router-link></li>
      </ol>
    </nav>

    <template v-if="product.id">

      <div class="row">
        <div class="col-md-6">
          <img :src="enlargedImagePath" class="rounded img-fluid">
        </div>
        <div class="col-md-6">
          <h1>{{ product.name }}</h1>
          <p style="font-size: 2em; color: silver;">{{ product.price }}€</p>
          <div class="tags my-3">
            <span class="badge badge-pill badge-info ml-2" v-for="tag in product.tags" :key="tag.name">{{ tag.name }}</span>
          </div>
          <p>{{ product.description }}</p>
        </div>
      </div>

    </template>

  </div>
</template>

<script>
export default {
  name: 'ProductDetail',
  inject: ['productService'],
  data: function() {
    return {
      product: {}
    }
  },
  computed: {
    enlargedImagePath: function() {
      return this.product.photo.replace('h_240,w_318', 'h_720,w_954');
    }
  },
  created: function() {
    const vm = this;
    this.productService.getProduct(this.$route.params.productId).then(data => {
      vm.product = data
    });
  }
}
</script>

<style scoped>
</style>
