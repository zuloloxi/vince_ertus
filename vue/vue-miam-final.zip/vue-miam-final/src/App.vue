<template>
  <div id="app">
    <nav class="navbar fixed-top navbar-light" style="background-color: #e3f2fd;">
      <!-- Logo -->
      <router-link class="navbar-brand" to="/">
        <img src="./assets/vuemiam-logo.png" width="150">
      </router-link>
      <!-- Order Info -->
      <div class="ml-auto">
        &nbsp;
      </div>
      <!-- Cart Icon -->
      <CartIcon />
    </nav>

    <div class="container">
      <router-view></router-view>
    </div><!-- .container -->
  </div>
</template>

<script>
import CartIcon from './components/CartIcon.vue'
import ProductList from './components/ProductList.vue'

import ProductService from './services/product-service'
import CartService from './services/cart-service'

export default {
  name: 'app',
  components: {
    CartIcon
  },
  // Dependency injection - Provide global, singleton services.
  provide: function () {
    return {
      productService: new ProductService(),
      cartService: new CartService(),
    }
  }
}
</script>

<style>
</style>
