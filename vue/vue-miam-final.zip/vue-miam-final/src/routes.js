/**
 * @file
 * Application routes.
 */
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

import ProductList from './components/ProductList'
import ProductDetail from './components/ProductDetail'
import CartDetail from './components/CartDetail'

// Define some routes
const routes = [
  { path: '/', redirect: '/products' },
  { path: '/products', component: ProductList },
  { path: '/product/:productId', component: ProductDetail },
  { path: '/cart', component: CartDetail },
]

// Create the router instance
const router = new VueRouter({
  routes // short for `routes: routes`
})

export default router