/**
 * @file
 * Product service - Handles interactions with the backend.
 */
import Product from '../models/product'

class ProductService {

  constructor() {
    this.baseUrl = 'http://localhost:3004';
  }

  /**
   * Load the list of all products.
   */
  async getProducts() {
    const resp = await fetch(`${this.baseUrl}/products`);
    const productArray = await resp.json();
    // Re-hydrate JSON.
    return productArray.map(productData => new Product(productData));
  }

  /**
   * Load a specific product.
   */
  async getProduct(productId) {
    const resp = await fetch(`${this.baseUrl}/products/${productId}`);
    const productData = await resp.json();
    // Re-hydrate JSON.
    return new Product(productData);
  }

  /**
   * Load the product with the given slug
   */
  async getProductBySlug(slug) {
    const resp = await fetch(`${this.baseUrl}/products?slug=${slug}`);
    const results = await resp.json();
    // Re-hydrate JSON.
    return new Product(results[0]);  // garde le 1er objet dans la liste des obj renvoyés
  }

}

export default ProductService

