/**
 * @file
 * Application routes.
 */
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

/* Declare routes here */