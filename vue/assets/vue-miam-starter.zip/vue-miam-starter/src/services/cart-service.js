/**
 * @file
 * Cart service - Handles products stored in the cart.
 */

class CartService {

}

export default CartService
