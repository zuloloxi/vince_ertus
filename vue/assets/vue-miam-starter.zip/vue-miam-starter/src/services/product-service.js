/**
 * @file
 * Product service - Handles interactions with the backend.
 */
import Product from '../models/product'

class ProductService {

}

export default ProductService
