/**
 * @file
 * Class representing a Product for sale on the VueMiam website.
 */

class Product {

}

export default Product