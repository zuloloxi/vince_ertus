<template>
  <div>
    Hello, {{ name }} !
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    name: String
  }
}
</script>

<style scoped>
/* Mettre ici les CSS scopées à ce composant */
</style>
